﻿using UnityEngine;
using UnityEngine.UI;

public class GameButton : MonoBehaviour {

    public GameObject go;
    public Image icon;
    public GameObject selection;
    private object GameObjects;

    GameObject[] x;
    GameObject[] y;
    GameObject[] z;

    public void AddObject(GameObject newObject)
    {
        go = newObject;

        x = GameObject.FindGameObjectsWithTag("BotonObjetos");
        y = GameObject.FindGameObjectsWithTag("BotonLugares");
        z = GameObject.FindGameObjectsWithTag("BotonEdificios");

        SpriteRenderer sr = go.GetComponent<SpriteRenderer>();
        icon.sprite = sr.sprite;
        icon.enabled = true;
    }

    public void ClearSlot()
    {
        go = null;

        icon.sprite = null;
        icon.enabled = false;
    }

    public void marcarObjs()
    {
        GameObject[] botones = x;
        for (int i = 0; i < botones.Length; i++)
        {
            if(botones[i].name != this.name)
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
            else
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(true);
            }
        }
    }

    public void marcarLugs()
    {
        GameObject[] botones = y;
        for (int i = 0; i < botones.Length; i++)
        {
            if (botones[i].name != this.name)
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
            else
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(true);
            }
        }
    }

    public void marcarEdif()
    {
        GameObject[] botones = z;
        for (int i = 0; i < botones.Length; i++)
        {
            if (botones[i].name != this.name)
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
            else
            {
                GameObject obj = botones[i];
                GameButton bg = obj.GetComponent<GameButton>();
                bg.selection.SetActive(true);
            }
        }
    }

    public void desmarcar(GameObject[] x)
    {
        GameObject[] botones = x;
        for (int i = 0; i < botones.Length; i++){
            go = botones[i];
            GameButton bg = go.GetComponent<GameButton>();
            bg.selection.SetActive(false);
        }
    }
}
