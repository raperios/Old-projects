﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectsUI : MonoBehaviour {

    public Transform parentObject;
    GameManager gm;
    GameButton[] buttons;

	// Use this for initialization
	void Start () {
        gm = GameManager.instance;
        gm.onItemChangedCallBack += UpdateUI;

        buttons = parentObject.GetComponentsInChildren<GameButton>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    void UpdateUI()
    {
        for(int i = 0; i < buttons.Length; i++)
        {
            int space = (int)Random.Range(0.0f, 11.0f);
            Debug.Log(space);
            GameObject go = gm.darObjetos()[space];
            buttons[i].AddObject(go);
        }
    }
}
