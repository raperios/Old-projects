﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour {

    public GameManager gm;
    int aSuperar;
    int puntaje;
    public Text mostrarSuperar;
    public Text mostrarMisPuntos;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        aSuperar = gm.highScore;
        puntaje = gm.puntos;

        mostrarMisPuntos.text = puntaje.ToString();
        mostrarSuperar.text = aSuperar.ToString();

	}
}
