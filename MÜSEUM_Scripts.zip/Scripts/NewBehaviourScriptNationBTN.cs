﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NewBehaviourScriptNationBTN : MonoBehaviour {
    // Use this for initialization
    public Text Cultura;
    public Text Descripcion;

	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void myTag()
    {
        Text[] myTit = Resources.LoadAll<Text>("Prefabs/Titulos");
        Text[] myDes = Resources.LoadAll<Text>("Prefabs/Descripciones");

        for(int i = 0; i < myTit.Length; i++)
        {
            Text bubble = myTit[i];
            Text bubble2 = myDes[i];
            if (bubble.tag == this.tag) {
                Cultura.text = bubble.text;
                Debug.Log("alright!");
            }
            if(bubble2.tag == this.tag)
            {
                Descripcion.text = bubble2.text;
                Debug.Log("wohoo!");
            }
        }


    }
}
