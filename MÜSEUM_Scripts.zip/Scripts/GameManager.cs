﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public int highScore;
    public int puntos = 0;
    public Text puntuacion;
    public float time;
    public Text tiempo;
    public GameObject victoryScreen;
    public GameObject defeatScreen;

    public static GameManager instance;
    void Awake()
    {
        instance = this;
    }

    public delegate void OnItemChanged();
    public OnItemChanged onItemChangedCallBack;

    string[] culturas = new string[12];
    public Text cultura;

    public static GameObject[] myObjects;
    public static GameObject[] myTerritories;
    public static GameObject[] myBuildings;
    List<GameObject> territorios = new List<GameObject>();



    // Use this for initialization
    void Start() {
        culturas[0] = "MUISCA";
        culturas[1] = "HINDÚ";
        culturas[2] = "CHEROKEE";
        culturas[3] = "AZTECA";
        culturas[4] = "QUIMBAYA";
        culturas[5] = "GRIEGA";
        culturas[6] = "KONGO";
        culturas[7] = "INGLESA";
        culturas[8] = "CHINA";
        culturas[9] = "JAPONESA";
        culturas[10] = "MONGOL";
        culturas[11] = "RUSA";


        myObjects = Resources.LoadAll<GameObject>("Prefabs/Objetos");
        myTerritories = Resources.LoadAll<GameObject>("Prefabs/Territorios");
        myBuildings = Resources.LoadAll<GameObject>("Prefabs/Edificaciones");

        if (cultura.text == "CULTURA")
        {
            int c = (int)Random.Range(0.0f, 11.0f);
            cultura.text = culturas[c];
        }

        GameObject panOb = GameObject.FindGameObjectWithTag("PanelObjetos");
        if (panOb != null) {
            updateButtons();
        }

        GameObject panLug = GameObject.FindGameObjectWithTag("PanelLugares");
        if(panLug != null)
        {
            updateButtonsLug();
        }
        GameObject panEd = GameObject.FindGameObjectWithTag("PanelEdificios");
        if(panEd != null)
        {
            updateButtonsEdif();
        }
    }

    // Update is called once per frame
    void Update() {

        if(time <= 0)
        {
            GameOver();
        }
        else
        {
            time -= Time.deltaTime;
            tiempo.text = Mathf.Round(time).ToString();

            puntuacion.text = puntos.ToString();
        }
	}

    public GameObject[] darObjetos()
    {
        return myObjects;
    }

    public void UpdateBoardOK()
    {
        bool existe1 = false;
        bool existe2 = false;
        bool existe3 = false;
        bool correcto1 = true;
        bool correcto2 = true;
        bool correcto3 = true;
        GameButton gb1 = null;
        GameButton gb2 = null;
        GameButton gb3 = null;
		GameButton opt1 = null;
		GameButton opt2 = null;
		GameButton opt3= null;

        GameObject[] botonesObjs = GameObject.FindGameObjectsWithTag("BotonObjetos");
        GameObject[] botonesLugs = GameObject.FindGameObjectsWithTag("BotonLugares");
        GameObject[] botonesEdfs = GameObject.FindGameObjectsWithTag("BotonEdificios");

        GameObject panObj = GameObject.FindGameObjectWithTag("PanelObjetos");
        GameObject panLug = GameObject.FindGameObjectWithTag("PanelLugares");
        GameObject panEdf = GameObject.FindGameObjectWithTag("PanelEdificios");
        if (panObj != null)
        {
            for (int i = 0; i < botonesObjs.Length; i++)
            {
                GameButton temp = botonesObjs[i].GetComponent<GameButton>();
                GameObject obj = temp.go;
				Debug.Log (temp.go.tag);
                if (temp.go.tag == cultura.text)
                {
                    existe1 = true;
                    if (temp.selection.activeSelf)
                    {
                        gb1 = temp;
                    }
                }
				if (temp.selection.activeSelf) {
					opt1 = temp;
				}
            }
           
            if (existe1 && gb1 != null)
            {
				GameObject go = gb1.go;
				if (gb1.selection.activeSelf && gb1.go.tag == cultura.text)
                {
                    correcto1 = true;
					Debug.Log("aja");
                }

                else
                {
                    correcto1 = false;
                }
                    
            }
            else if (existe1 && gb1 == null)
            {
                correcto1 = false;
                
            }
            else if(!existe1 && gb1 != null)
            {
                correcto1 = false;
            }
			else if(!existe1 && opt1 == null){
				correcto1 = true;
			}
			else if(!existe1 && gb1 == null && opt1.go.tag != cultura.text)
            {
                correcto1 = false;
            }
        }
        if(panLug != null)
        {
            for (int i = 0; i < botonesLugs.Length; i++)
            {
                GameButton temp = botonesLugs[i].GetComponent<GameButton>();
                GameObject obj = temp.go;
                if (temp.go.tag == cultura.text)
                {
                    existe2 = true;
                    if (temp.selection.activeSelf)
                    {
                        gb2 = temp;
                    }
                }
				if (temp.selection.activeSelf) {
					opt2 = temp;
				}
            }
            if (existe2 && gb2 != null)
            {
                if (gb2.selection.activeSelf) {
                    correcto2 = true;
                }
                    
                else
                    correcto2 = false;
            }
            else if (existe2 && gb2 == null)
            {
                correcto2 = false;
            }
            else if (!existe2 && gb2 != null)
            {
                correcto2 = false;
            }
			else if(!existe2 && opt2 == null){
				correcto2 = true;
			}
			else if(!existe2 && gb2 == null && opt2.go.tag != cultura.text)
			{
				correcto2 = false;
			}
        }
        if (panEdf != null)
        {
            for (int i = 0; i < botonesEdfs.Length; i++)
            {
                GameButton temp = botonesEdfs[i].GetComponent<GameButton>();
                GameObject obj = temp.go;
                if (temp.go.tag == cultura.text)
                {
                    existe3 = true;
                    if (temp.selection.activeSelf)
                    {
                        gb3 = temp;
                    }
                }
				if (temp.selection.activeSelf) {
					opt3 = temp;
				}
            }
            if (existe3 && gb3 != null)
            {
                if (gb3.selection.activeSelf)
                {
                    correcto3 = true;
                }

                else
                    correcto3 = false;
            }
            else if (existe3 && gb3 == null)
            {
                correcto3 = false;
            }
            else if (!existe3 && gb3 != null)
            {
                correcto3 = false;
            }
			else if(!existe3 && opt3 == null){
				correcto1 = true;
			}
			else if(!existe3 && gb3 == null && opt3.go.tag != cultura.text)
			{
				correcto3 = false;
			}
        }

        if (correcto1 && correcto2 && correcto3){
            puntos++;
        }
        else
        {
            puntos--;
        }



        int c = (int)Random.Range(0.0f, 11.0f);
        cultura.text = culturas[c];

        updateButtons();
        updateButtonsLug();
        updateButtonsEdif();
    }

    public void UpdateBoardNotOK(){
        GameObject[] botonesObjs = GameObject.FindGameObjectsWithTag("BotonObjetos");
        GameObject[] botonesLugs = GameObject.FindGameObjectsWithTag("BotonLugares");
        GameObject[] botonesEdfs = GameObject.FindGameObjectsWithTag("BotonEdificios");

        GameObject panObj = GameObject.FindGameObjectWithTag("PanelObjetos");
        GameObject panLug = GameObject.FindGameObjectWithTag("PanelLugares");
        GameObject panEdif = GameObject.FindGameObjectWithTag("PanelEdificios");

        if(panObj != null)
        {
            for (int i = 0; i < botonesObjs.Length; i++)
            {
                GameObject go = botonesObjs[i];
                GameButton bg = go.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
        }
        
        if(panLug != null)
        {
            for (int i = 0; i < botonesLugs.Length; i++)
            {
                GameObject go = botonesLugs[i];
                GameButton bg = go.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
        }
        
        if(panEdif != null)
        {
            for (int i = 0; i < botonesEdfs.Length; i++)
            {
                GameObject go = botonesEdfs[i];
                GameButton bg = go.GetComponent<GameButton>();
                bg.selection.SetActive(false);
            }
        }
    }

    public void updateButtons()
    {
        GameObject[] botonesObjs = GameObject.FindGameObjectsWithTag("BotonObjetos");
        for (int i = 0; i < botonesObjs.Length; i++)
        {
            GameButton temp = botonesObjs[i].GetComponent<GameButton>();
            temp.ClearSlot();
            temp.desmarcar(botonesObjs);
            int d = (int)Random.Range(0.0f, 24.0f);
            temp.AddObject(myObjects[d]);
        }

        bool dup = false;
        bool culuraEsta = false;
        for (int i = 0; i < botonesObjs.Length; i++)
        {
            GameButton uno = botonesObjs[i].GetComponent<GameButton>();
            if (cultura.text == uno.go.tag)
            {
                culuraEsta = true;
            }

            for (int j= i+1; j < botonesObjs.Length; j++)
            {
                GameButton dos = botonesObjs[j].GetComponent<GameButton>();

                if (uno.icon.sprite == dos.icon.sprite)
                {
                    dup = true;
                }
            }
        }
        if (dup)
        {
            updateButtons();
        }
        if(!culuraEsta){

        }


    }

    public void updateButtonsLug()
    {
        GameObject[] botonesLugs = GameObject.FindGameObjectsWithTag("BotonLugares");
        for (int i = 0; i < botonesLugs.Length; i++)
        {
            GameButton temp = botonesLugs[i].GetComponent<GameButton>();
            temp.ClearSlot();
            temp.desmarcar(botonesLugs);
            int d = (int)Random.Range(0.0f, 36.0f);
            temp.AddObject(myTerritories[d]);
        }

        bool dup = false;
        bool culuraEsta = false;
        for (int i = 0; i < botonesLugs.Length; i++)
        {
            GameButton uno = botonesLugs[i].GetComponent<GameButton>();
            if (cultura.text == uno.go.tag)
            {
                culuraEsta = true;
            }

            for (int j = i + 1; j < botonesLugs.Length; j++)
            {
                GameButton dos = botonesLugs[j].GetComponent<GameButton>();

                if (uno.icon.sprite == dos.icon.sprite)
                {
                    dup = true;
                }
            }
        }
        if (dup)
        {
            updateButtonsLug();
        }
        if (!culuraEsta)
        {

        }
    }

    public void updateButtonsEdif()
    {
        GameObject[] botonesEdif = GameObject.FindGameObjectsWithTag("BotonEdificios");
        for (int i = 0; i < botonesEdif.Length; i++)
        {
            GameButton temp = botonesEdif[i].GetComponent<GameButton>();
            temp.ClearSlot();
            temp.desmarcar(botonesEdif);
            int d = (int)Random.Range(0.0f, 22.0f);
            temp.AddObject(myBuildings[d]);
        }

        bool dup = false;
        bool culuraEsta = false;
        for (int i = 0; i < botonesEdif.Length; i++)
        {
            GameButton uno = botonesEdif[i].GetComponent<GameButton>();
            if (cultura.text == uno.go.tag)
            {
                culuraEsta = true;
            }

            for (int j = i + 1; j < botonesEdif.Length; j++)
            {
                GameButton dos = botonesEdif[j].GetComponent<GameButton>();

                if (uno.icon.sprite == dos.icon.sprite)
                {
                    dup = true;
                }
            }
        }
        if (dup)
        {
            updateButtonsEdif();
        }
        if (!culuraEsta)
        {

        }
    }

    void GameOver()
    {
        if (puntos >= highScore)
        {
            victoryScreen.SetActive(true);
        }
        else
        {
            defeatScreen.SetActive(true);
        }
    }
}
