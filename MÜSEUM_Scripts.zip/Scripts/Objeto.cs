﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Objeto : MonoBehaviour {

    public int tipo;
    public string nombre;
	// Use this for initialization
}
